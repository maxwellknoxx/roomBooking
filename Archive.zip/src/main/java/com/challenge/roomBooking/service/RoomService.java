package com.challenge.roomBooking.service;

import java.util.List;

import com.challenge.roomBooking.model.RoomDTO;

public interface RoomService {
	
	List<RoomDTO> findAll();

}
