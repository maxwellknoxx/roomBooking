package com.challenge.roomBooking.utils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.challenge.roomBooking.entity.BookingCalendar;
import com.challenge.roomBooking.model.BookingCalendarDTO;

@Component
public class BookingCalendarMapper {

	public static BookingCalendarDTO getModel(BookingCalendar entity) {
		return BookingCalendarDTO.builder().id(entity.getId()).bookingId(entity.getBooking().getId())
				.day(entity.getDay()).build();
	}

	public static List<BookingCalendarDTO> getListModel(List<BookingCalendar> entities) {
		return entities
				.stream().filter(Objects::nonNull).map(entity -> BookingCalendarDTO.builder().id(entity.getId())
						.bookingId(entity.getBooking().getId()).day(entity.getDay()).build())
				.collect(Collectors.toList());
	}
}
