package com.challenge.roomBooking.enums;

public enum RoomType {
	
	SINGLE,
	DOUBLE,
	SUITE

}
