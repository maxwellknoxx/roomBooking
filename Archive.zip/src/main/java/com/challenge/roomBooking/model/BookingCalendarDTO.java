package com.challenge.roomBooking.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class BookingCalendarDTO {
	
	private Long id;
	private Long bookingId;
	private String day;

}
